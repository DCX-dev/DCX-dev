package org.sinytra.connector.mod;

public class DummyTarget {
}
